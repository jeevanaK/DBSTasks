package com.capgemini.AsyncCalls;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsyncCallsApplicationTests {

	@Test
	void contextLoads() {
	}

}
