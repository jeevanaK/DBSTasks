package com.capgemini.AsyncCalls;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AsyncController implements CommandLineRunner{

	@Autowired
	private AsyncService service;
	
	@Override
    public void run (String... args) throws Exception {
        // Start the clock
        long start = System.currentTimeMillis();

        // Kick of multiple, asynchronous lookups
        CompletableFuture<AsyncEntity> page1 = service.lookForValue(1);
        CompletableFuture<AsyncEntity> page2 = service.lookForValue(3);
        CompletableFuture<AsyncEntity> page3 = service.lookForValue(10);

        // Join all threads so that we can wait until all are done
        CompletableFuture.allOf(page1, page2, page3).join();

        // Print results, including elapsed time
        System.out.println("Elapsed time: " + (System.currentTimeMillis() - start));
        System.out.println("--> " + page1.get());
        System.out.println("--> " + page2.get());
        System.out.println("--> " + page3.get());
    }

}
