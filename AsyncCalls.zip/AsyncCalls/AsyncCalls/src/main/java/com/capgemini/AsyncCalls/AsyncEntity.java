package com.capgemini.AsyncCalls;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class AsyncEntity {
	private Integer id;
	private Integer userId;
	private String title;
	private String completed;
	
	public AsyncEntity() {} 
	
	public AsyncEntity(Integer id, Integer userId, String title, String completed) {
		super();
		this.id = id;
		this.userId = userId;
		this.title = title;
		this.completed = completed;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCompleted() {
		return completed;
	}
	public void setCompleted(String completed) {
		this.completed = completed;
	}
	
	
	 @Override
	    public String toString() {
	        return "Book [id=" + id + ", title=" + title + "]";
	    }

}
